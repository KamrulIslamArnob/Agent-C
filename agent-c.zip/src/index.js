const express = require('express');
const app = express();
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

// Supabase client setup
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);

app.use(express.json());

// GET all rows from 'test' table
app.get('/test', async (req, res) => {
    try {
        const { data, error } = await supabase.from('test').select('*');
        if (error) {
            console.error('Error fetching data:', error);
            throw error;
        }

        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
